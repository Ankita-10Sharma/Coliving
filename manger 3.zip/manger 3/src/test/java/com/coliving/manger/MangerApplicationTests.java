package com.coliving.manger;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MangerApplicationTests {

	@Test
	void contextLoads() {
	}

}

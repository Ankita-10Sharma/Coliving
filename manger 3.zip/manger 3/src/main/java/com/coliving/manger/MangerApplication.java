package com.coliving.manger;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration;
import org.springframework.context.annotation.ComponentScan;

@ComponentScan("com.coliving.manager")
@SpringBootApplication(exclude = {SecurityAutoConfiguration.class })
public class MangerApplication {

	public static void main(String[] args) {
		SpringApplication.run(MangerApplication.class, args);
	}

}

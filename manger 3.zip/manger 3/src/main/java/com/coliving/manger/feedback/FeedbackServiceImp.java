package com.coliving.manger.feedback;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.coliving.manger.model.Feedback;

@Service
public class FeedbackServiceImp implements FeedbackService{

	@Autowired
	private FeedbackRepository fr;
	@Override
	public String addFeedback(Feedback f) {
		 fr.save(f);
		 return "Sucessfull";
	}

//	@Override
//	public List<Feedback> getAllFeedbacks() {
////		return fr.save(Sort.by(Sort.Direction.DESC,"id"));
//		return "sucess";
//	}

}

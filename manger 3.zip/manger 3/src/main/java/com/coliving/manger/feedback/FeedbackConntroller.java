package com.coliving.manger.feedback;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.coliving.manger.model.Feedback;

@RestController
@RequestMapping("/api/feedback")
@CrossOrigin
public class FeedbackConntroller {

	@Autowired
	private FeedbackServiceImp fsi;
	
	@PostMapping("/add")
	public String addFeedback(@RequestBody Feedback f) {
		fsi.addFeedback(f);
		return "Sucessfull";
	}
//	@GetMapping("/get")
//	public List<Feedback> getAllFeedbacks(){
//		return fsi.getAllFeedbacks();
//	}
}

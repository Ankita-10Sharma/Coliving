package com.coliving.manger.feedback;

import java.util.List;

import com.coliving.manger.model.Feedback;

public interface FeedbackService {

	public String addFeedback(Feedback f) ;
//	public List<Feedback> getAllFeedbacks();
}
